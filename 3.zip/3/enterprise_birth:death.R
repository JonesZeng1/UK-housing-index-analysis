###loading data
housing <- read.csv('data_clean.csv')
enterprise <- read.csv('business-demographics.csv')
pricing <- read.csv('Average-prices-2021-11.csv')


###library packages
install.packages("installr")
install.packages("tidyverse")
library(installr)
library(tidyverse)
library(data.table)
updateR()

###order the data
order(housing$AvgDifference)


head(pricing)
head(housing)
head(enterprise)


#sorting data
startday <- as.Date("2004-01-01")
endday <- as.Date("2020-01-01")

new <- pricing[which(pricing$Date >= startday & pricing$Date <= endday),]
head(new1)
new1 <- new %>% as_tibble() %>% filter(Area_Code == 'S92000003')  
new2 <- new %>% as_tibble() %>% filter(Area_Code == 'E09000020')

rows = c(1,13,25,37,49,61,73,85,97,109,121,133,145,157,169,181,193)

new1 <- new1[rows,]
new2 <- new2[rows,]
new3 <- rbind(new1,new2)

ent1 <- enterprise %>% as_tibble() %>% filter(code == 'S92000003')
ent2 <- enterprise %>% as_tibble() %>% filter(code == 'E09000020')
ent3 <- rbind(ent1,ent2)

all <- cbind(new3,ent3)
head(all)
all <- all[,c(2,3,6,10,13,15)]
head(all)

#drawing diagrams
options(repr.plot.width = 18, repr.plot.height =10)
ggplot(data=all, aes(x=year, y=birth_rate, group=Region_Name)) +
  geom_line(aes(color=Region_Name))+
  geom_point(aes(color=Region_Name)) + theme(axis.text.x = element_text( size = 15),
                                      axis.text.y = element_text(size = 15),
                                      axis.title.x = element_text(size = 20),
                                      axis.title.y = element_text(size = 20),
                                      legend.text = element_text(size = 12),
                                      legend.title = element_text(size = 25),
                                      plot.title = element_text(size = 25, face = "bold"),
                                      panel.border = element_blank(),
                                      panel.background = element_blank(),
                                      # Add axis line
                                      axis.line = element_line(colour = "grey")) +
  ggtitle("birth rate of enterprise versus house price change")

ggplot(data=all, aes(x=year, y=death_rate, group=Region_Name)) +
  geom_line(aes(color=Region_Name))+
  geom_point(aes(color=Region_Name)) + theme(axis.text.x = element_text( size = 15),
                                             axis.text.y = element_text(size = 15),
                                             axis.title.x = element_text(size = 20),
                                             axis.title.y = element_text(size = 20),
                                             legend.text = element_text(size = 12),
                                             legend.title = element_text(size = 25),
                                             plot.title = element_text(size = 25, face = "bold"),
                                             panel.border = element_blank(),
                                             panel.background = element_blank(),
                                             # Add axis line
                                             axis.line = element_line(colour = "grey")) +
  ggtitle("death rate of enterprise versus house price change")


#regression summary
fm <- lm(birth_rate~Annual_Change,data = all)
summary(fm)
